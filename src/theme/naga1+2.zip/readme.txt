﻿Theme Name: naga1
Theme URI: 미리보기URL X
Maker: 나연가온아빠
Maker URI: http://www.sitemake.kr
Version: 1
Detail: CM-001 테마를 반응형으로 수정하였습니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html