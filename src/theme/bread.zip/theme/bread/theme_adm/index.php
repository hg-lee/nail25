<?php
include_once('_common.php');

goto_url('./footerinfo.php');
?>