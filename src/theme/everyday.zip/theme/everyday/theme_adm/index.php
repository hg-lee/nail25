<?php
include_once('_common.php');

goto_url('./maincategory.php');
?>