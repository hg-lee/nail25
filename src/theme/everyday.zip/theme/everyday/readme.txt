Theme Name: everyday
Theme URI: http://theme.sir.kr/gnuboard5/demo/basic
Maker: SIR
Maker URI: http://sir.kr
Version: 1.0.0
Detail: everyday 테마는  SIR에서 제공하는 영카트5.3 반응형 테마입니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html