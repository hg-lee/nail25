Theme Name: BS4-Aside v2.0
Theme URI: http://iplace.co.kr/bs4/theme/bs4
Maker: Fiancee(iPlace)
Maker URI: http://iplace.co.kr
Version: 2.0
Detail: BS4-Aside 테마는 SIR에서 제공하는 그누보드5에 Bootstrap 4를 적용하여 제작한 반응형 테마입니다. BS4-Aside 테마는 웹표준 및 접근성을 준수합니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html