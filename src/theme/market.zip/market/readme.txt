Theme Name: Market
Theme URI: http://theme.sir.kr/youngcart53/demo/market
Maker: SIR
Maker URI: http://sir.kr
Version: 그누보드 5.3.1.5
Detail: black bean 테마는 SIR에서 제공하는 그누보드5.3 테마입니다. Market 테마는 웹표준 및 접근성을 준수합니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html